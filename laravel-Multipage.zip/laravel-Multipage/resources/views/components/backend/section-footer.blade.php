<div class="row">
    <div class="col">
        <small class="text-muted float-end">
            {{ $slot }}
        </small>
    </div>
</div>
