<?php

return [

    'name' => 'নাম',
    'slug' => 'Slug',
    'created_by_alias' => 'Author Name Alias',
    'intro' => 'ইন্ট্রো',
    'content' => 'কন্টেন্ট',
    'image' => 'ছবি',
    'category_id' => 'ক্যাটাগরি',
    'type' => 'Type',
    'is_featured' => 'Is Featured',
    'tags' => 'ট্যাগ',
    'status' => 'স্ট্যাটাস',
    'published_at' => 'প্রকাশের সময়',

    'meta_title' => 'Meta Title',
    'meta_keywords' => 'Meta Keywords',
    'meta_description' => 'Meta Description',
    'meta_og_image' => 'Meta Open Graph Image',
    'meta_og_url' => 'Meta Open Graph URL',
    'order' => 'Order',

];
