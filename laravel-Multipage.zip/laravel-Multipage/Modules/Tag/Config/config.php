<?php

return [
    'name' => 'Tag',
];
