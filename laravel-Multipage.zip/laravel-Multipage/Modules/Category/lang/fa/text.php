<?php

return [

    'name' => 'نام',
    'slug' => 'نامک',
    'description' => 'توضیحات',
    'status' => 'وضعیت',
    'created_by' => 'ایجاد شده توسط',
    'updated_at' => 'آخرین ویرایش در',
    'updated_by' => 'ویرایش شده توسط',
    'deleted_by' => 'حذف شده توسط',
    'action' => 'عملیات',

];
